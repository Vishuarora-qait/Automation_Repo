/**
* This is a sample test recorded in selenium ide and exported to eclipse 
* Step 1 : Open snapdeal.com
* Step 2 : Search A product - Mobile
* Step 3 : Select First Product
* Step 4 : Add the product to cart
* Step 5 : Verify the product has been added to cart
* 
* Task : You have to fix this test and run it.
*/

/**
* This is a sample test recorded in selenium ide and exported to eclipse 
* Step 1 : Open snapdeal.com
* Step 2 : Search A product - Mobile
* Step 3 : Select First Product
* Step 4: Switch driver to new opened window
* Step 4 : Add the product to cart
* Step 5 : Add the product to cart
* Step 6: Verify product has been added to cart for this, 'Proceed to checkout button and 'View Cart' button should be there
* Step 7: Click on 'Proceed to 'Checkout' button
* 
*/



package com.qait.demo.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.*;
import static org.testng.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class TestLevel1_SnapDeal_Selenium_Imported_From_IDE_Broken_Needs_To_Be_Fixed {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  String winHandleBefore;
 
  
  @BeforeClass(alwaysRun = true)
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    driver.manage().window().maximize();
    baseUrl = "https://www.snapdeal.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testECommerceSite() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("inputValEnter")).click();
    driver.findElement(By.id("inputValEnter")).clear();
    driver.findElement(By.id("inputValEnter")).sendKeys("mobile");
    driver.findElement(By.xpath("//button[@onclick=\"submitSearchForm('go_header');\"]")).click();
        
    winHandleBefore= driver.getWindowHandle();
    
    driver.findElement(By.xpath("(//img[contains(@class,'product-image')])[1]")).click();
    
    for (String winHandle: driver.getWindowHandles()){
    	driver.switchTo().window(winHandle);
    
    }
    driver.findElement(By.xpath(".//*[@id='add-cart-button-id']/span")).click();
    
    WebElement viewcart = driver.findElement(By.xpath("//div[@class='cart-item-container row']/div[2]//div[2]/div[@class='btn btn-theme-secondary open-cart']"));
    boolean viewcartpresent = viewcart.isDisplayed();
    
    Assert.assertTrue(driver.findElement(By.xpath(".//*[@id='cartProductContainer']//div[@class='cart-item-container row']//div//a[@class='btn marR5']")).isDisplayed()&&viewcartpresent, "Assert Failed: Item not added to cart");
    System.out.println("Assert Passed: Item added to cart, proceed further to checkout");
    
    driver.findElement(By.xpath(".//*[@id='cartProductContainer']//div[@class='cart-item-container row']//div//a[@class='btn marR5']")).click();
    driver.close();
    
    driver.switchTo().window(winHandleBefore);
  }

  @AfterClass(alwaysRun = true)
  public void tearDown() throws Exception {
   driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
