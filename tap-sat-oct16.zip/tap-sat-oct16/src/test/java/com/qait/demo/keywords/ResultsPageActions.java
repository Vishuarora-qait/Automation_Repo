package com.qait.demo.keywords;



import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.events.WebDriverEventListener;
import org.testng.Assert;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.YamlReader;
import com.thoughtworks.selenium.Wait;
import com.thoughtworks.selenium.Wait.WaitTimedOutException;

public class ResultsPageActions extends GetPage {
	
	WebDriver driver;

    public ResultsPageActions(WebDriver driver) {
        super(driver, "ResultsPage");
        this.driver = driver;
    }

	
	public void verifySearchResults(String resultText) {
		isElementDisplayed("area_searchResult");
		Assert.assertTrue(element("txt_resultCount",resultText).isDisplayed(), "Result count section is not present");
		logMessage("Search Results successfully displayed");
	}
	
	
	public void getResponseCode(String url){
		logMessage("Status Code for the URL '"+url+"' :- "+ apiTester.getStatusCodeOfTheService(url));
	}

//	public void getHeaders(String url){
//		Map<String, List<String>> map = apiTester.getAllHeaderFields(url);
//		Iterator it = map.entrySet().iterator();
//		while(it.hasNext()){
//			logMessage("Map value:- "+it.next());
//		}
//	}


	public void clickFirstProduct() {
		
		//Assert.assertTrue(element("Firstelement").isDisplayed(), "Assert Failed: No element displayed");
		//System.out.println("Assert Passed: Element displayed and click on this product");
		String winHandleBefore = driver.getWindowHandle();
		element("Firstelement").click();
		for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);
		}

		
		
	}


	public void verifyResults(String yamlValue) {
		
		String label = element("SearchResultForSearchedTerm").getText();
		Assert.assertTrue(label.contains(yamlValue), "Assert Failed: Application does not display search results according to the searched term entered");
		System.out.println("Assert Passed: Application displays search results according to the searched term entered");
		
		
		
	}
	
	
    
    
}
