package com.org.LearningMaven;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;

public class HelloTest {

	@Test
	
	public void Login(){
		
		System.out.println("Login into app");
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.youtube.com/watch?v=sBtSzMATZvQ");
	}
}
